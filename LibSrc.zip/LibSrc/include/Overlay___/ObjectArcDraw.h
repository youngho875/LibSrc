#pragma once

#include "ObjectDraw.h"
#include "ObjectArc.h"


#undef	AFX_DATA
#ifdef	OVERLAY_IMPL
#define	AFX_DATA	_declspec(dllexport)
#else
#define	AFX_DATA	_declspec(dllimport)
#endif

//---------------------------------------
// �ۼ���			: ����ȣ
// Ŭ������			: CObjectArcDraw
// ���				: ���� �׸���
// ������			: 2024-10-07
// ����������		:
// ����������		:
//---------------------------------------

namespace OVERLAY
{
	class AFX_DATA CObjectArcDraw : public CObjectDraw
	{
	public:
		CObjectArcDraw();
		~CObjectArcDraw();
		void Draw(OVERLAY::OBJECT* object, Gdiplus::Graphics* g, int nResolution = DRAW_RESOLUTION);
		void DrawOutLine(OVERLAY::OBJECT* object, Gdiplus::Graphics* g, int nResolution = DRAW_RESOLUTION);
		void DrawSelectPoint(OVERLAY::OBJECT* object, Gdiplus::Graphics* g);
		void DrawMap(OVERLAY::OBJECT* object, Gdiplus::Graphics* g, int nResolution = DRAW_RESOLUTION);
	private:
		void DrawRotate(OVERLAY::OBJECT* object, Gdiplus::Graphics* g, int nResolution);
		void DrawObject(OVERLAY::OBJECT* object, Gdiplus::Graphics* g, int nResolution);
	};
}

#undef	AFX_DATA
#define	AFX_DATA