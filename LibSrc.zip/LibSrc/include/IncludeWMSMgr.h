#pragma once
#include "IncludeGeoDC.h"
#include "WMSMgr/WMSClient.h"
