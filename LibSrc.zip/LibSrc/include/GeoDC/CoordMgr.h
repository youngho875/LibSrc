#pragma once

#include <afxdisp.h>


#undef	AFX_DATA
#ifdef	GEODC_IMPL
#define	AFX_DATA	_declspec(dllexport)
#else
#define	AFX_DATA	_declspec(dllimport)
#endif

class AFX_DATA CCoordMgr
{
private:
	// Singleton: �����ڿ� ���� �����ڸ� private�� �̵��Ͽ� �ܺ� ���� ����
	CCoordMgr(void);
	friend CCoordMgr* CreateIndependentCoordMgr();
	CCoordMgr(const CCoordMgr&) = delete;            
	CCoordMgr& operator= (const CCoordMgr&) = delete; 

public:
	static CCoordMgr* GetInst(void);
	static void ReleaseInst(void); // ���� �ڵ� ȣȯ��
	void CCoordMgr::SetInst(CCoordMgr* instance);

public:
	void InitDisplayParameter(CRect rect);
	void InitDisplay(int nWidth, int nHeight);
	void SetCenterCoord(double lon, double lat);

	/*
	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
				long* nXScreenCoord, long* nYScreenCoord,
				double fCenterX, double fCenterY,
				double fWorldCenterX, double fWorldCenterY,
				double fScale);
	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
				long* nXScreenCoord, long* nYScreenCoord);
	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
				double* fXScreenCoord, double* fYScreenCoord);
	void ScreenXY2WorldXY(long nXScreenCoord, long nYScreenCoord,
				double* fXWorldCoord, double* fYWorldCoord,
				double fCenterX, double fCenterY,
				double fWorldCenterX, double fWorldCenterY,
				double fScale);
	void ScreenXY2WorldXY(long nXScreenCoord, long nYScreenCoord,
				double* fXWorldCoord, double* fYWorldCoord);
	*/
	
	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
				 long	*nXScreenCoord, long *nYScreenCoord, 
				 double fCenterX, double fCenterY, 
		 		 double fScale);
	void ScreenXY2WorldXY(int	nXScreenCoord, int nYScreenCoord,
				 double *fXWorldCoord, double *fYWorldCoord, 								
				 double fCenterX, double fCenterY, 
				 double fScale);
	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
					double *fXScreenCoord, double *fYScreenCoord, 
					double fCenterX, double fCenterY, 
					double fScale);

	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
					long	*nXScreenCoord, long *nYScreenCoord);

	void WorldXY2ScreenXY(double fXWorldCoord, double fYWorldCoord,
					double *fXScreenCoord, double *fYScreenCoord);

	void ScreenXY2WorldXY(int nXScreenCoord, int nYScreenCoord,
						 double *fXWorldCoord, double *fYWorldCoord);

	

	double DeltaXYToBearing(double fDeltaX, double fDeltaY);
	// ���� ����� ���� ª�� ���� �Լ��� inline���� ����
	inline double DeltaXYToRange(double fDeltaX, double fDeltaY)
	{
		return sqrt(fDeltaX * fDeltaX + fDeltaY * fDeltaY);
	};

	//double DeltaXYToRange(double fDeltaX, double fDeltaY);
	static	double DeltaVxVyToHeading(double fVelFactorX, double fVelFactorY);
	static	double DeltaVxVyToSpeed(double fVelFactorX, double fVelFactorY);

	void	SetDisplayCenter(double fCenterX, double fCenterY);
	void	GetDisplayCenter(double *fCenterX, double *fCenterY);

	void	SetNewCenter(double fNewCenterX, double fNewCenterY);

	void	CalcNewCenterAndScale(CRect rect);
	void	static HeadingSpeedToVxVy(int nSpeed, int nHeading, double *fVx, double *fVy);
	void	UTM_TO_WGP(double x, double y, int izone, double &lon, double &lat);

	void	PowerSet(CCoordMgr* inst);

	void WorldLonLat2ScreenXY(double fLonWorldCoord, double fLatWorldCoord,
		double* fXScreenCoord, double* fYScreenCoord,
		double fCenterX, double fCenterY,
		double fScale);
	void WorldLonLat2ScreenXY(double fLonWorldCoord, double fLatWorldCoord,
		long* fXScreenCoord, long* fYScreenCoord,
		double fCenterX, double fCenterY,
		double fScale);

public:
	double	m_fCenterX; 
	double	m_fCenterY; 
	double	m_fScale; 
	int		m_nScreenWidth; 
	int		m_nScreenHeight; 
	int		m_nDisplayViewWidth;
	int		m_nDisplayViewHeight; 
	double	m_fHorVerRatio;
	bool m_bFlat;
	double m_fWorldCenterX; // ���� ȭ�� �߽� �浵
	double m_fWorldCenterY; // ���� ȭ�� �߽� ����
};

#ifndef GP_COORDMGR
#define GP_COORDMGR CCoordMgr::GetInst()
#endif

#undef	AFX_DATA
#define	AFX_DATA






// Independent view state; caller owns the returned instance.
// Keep the private constructor ABI used by the existing GeoDC DLL.
inline CCoordMgr* CreateIndependentCoordMgr()
{
	return new CCoordMgr();
}
