// GStringNE.h: interface for the CGStringNE class.
//
//////////////////////////////////////////////////////////////////////

#pragma once



#undef	AFX_DATA
#ifdef	GEOTRANS_IMPL
#define	AFX_DATA	_declspec(dllexport)
#else
#define	AFX_DATA	_declspec(dllimport)
#endif

#define GMAX_NE_N	46	// N ������ȣ�� �ְ���
#define GMAX_NE_E	61	// E ������ȣ�� �ְ���
#define GMAX_MONTH	12
#define ZERO		0

typedef struct tagNETABLECOMPONENT {
	char	Nchar[3];
	char	Echar[3];
} tagNETABLECOMPONENT, TABLECOMPONENT;
typedef  tagNETABLECOMPONENT NETABLE;

#define GEXP_NE_POS			701	// ��ġ
#define GEXP_NE_AREA_BASE	702	// �⺻����
#define GEXP_NE_AREA_RADIUS	703	// �ݰ�
#define GEXP_NE_AREA_RECT	704	// ����
#define GEXP_NE_REFLINE		705	// ������

class CGStringGeo;

class CGPointGeo;
class CGPointGP;

/**
* NE ��ǥ�� TEXT ���� class
* @author ����ȣ
* @version 1.0
* @since 2024.07.
**/
class AFX_DATA CGStringNE : public CGStringGeo
{
public:
	CGStringNE();
	virtual ~CGStringNE();

	void Empty();
	BOOL IsEmpty() const;
	int IsValid(CString &str, BOOL bSet = FALSE);

	BOOL SetPoint(CGPointGP *pGP);
	BOOL SetPoint(CString &str);

	void GetPoint(CGPointGP *pGP);
	CString GetString();

	const CGStringNE& operator = (const CGStringNE &right);

	CGPointGP GetBasisGP() const;
	CGPointGP SetBasisGP(CGPointGP gpBasis);

	int SetMonth(int nMonth = 0);
	int GetMonth() { return m_nMonth; }

	NETABLE* GetNeTable();

	int FindNEtable(CString str, BOOL bN, int month = 0);

	void InitializeNeTable();
	BOOL ReadNeTableFormFile(CString *psAppDate, CString *psBaseGP, int *pnCntN, int *pnCntE, CStringArray *psArrN, CStringArray *psArrE);

private:
	int IsValidPos(CString &str, BOOL bSet = FALSE);
	int IsValidArea(CString &str, BOOL bSet = FALSE);
	int IsValidRefLine(CString &str, BOOL bSet = FALSE);

private:
	BOOL		m_bRead;

	CGPointGP	m_gpBasis;
	UINT		m_nMonth;

private:
	NETABLE	m_NeTable[GMAX_NE_E][GMAX_MONTH];

	BYTE	m_Narea;	// N ������ȣ
	UINT	m_Nsec;		// N ��
	BYTE	m_Earea;	// E ������ȣ
	UINT	m_Esec;		// E ��

	// NE ��ǥ ǥ�� ���
	UINT	m_expNE;
	
	UINT	m_mile;		// ����
	UINT	m_Ncount;	// N ������ ����
	UINT	m_Ecount;	// E ������ ����
};

#undef	AFX_DATA
#define	AFX_DATA


