#pragma once


#undef	AFX_DATA
#ifdef	HEIGHTS_IMPL
#define	AFX_DATA	_declspec(dllexport)
#else
#define	AFX_DATA	_declspec(dllimport)
#endif

/* ************************************************************************** */

#define _coeffs (65341) //!< Size of correction and harmonic coefficients arrays (361*181)
#define _nmax   (360)   //!< Maximum degree and orders of harmonic coefficients.
#define _361    (361)

/* ************************************************************************** */

class AFX_DATA CAltitude
{
public:
	CAltitude();
	virtual ~CAltitude();

public:
    double get_Heights(double latitude, double longitude);

private:
    double hundu(double p[_coeffs + 1], double sinml[_361 + 1], double cosml[_361 + 1], double gr, double re);
    void dscml(double rlon, double sinml[_361 + 1], double cosml[_361 + 1]);
    void legfdn(unsigned m, double theta, double rleg[_361 + 1]);
    void radgra(double lat, double lon, double* rlat, double* gr, double* re);
    double undulation(double lat, double lon);

};

#undef	AFX_DATA
#define	AFX_DATA