#pragma once

#include <afxmt.h>

#undef	AFX_DATA
#ifdef	WMSMGR_IMPL
#define	AFX_DATA	_declspec(dllexport)
#else
#define	AFX_DATA	_declspec(dllimport)
#endif

#include <atlimage.h>
#include <unordered_map>
#include <list>
#include <deque>
#include <synchapi.h> // SRWLock��
#include <set>
#include <map>
#include <gdiplus.h>



#define     MAX_CACHE_SIZE  1000


struct TileData
{
    int x, y, z;
    CImage image;
    std::list<CString>::iterator itList;     // ����Ʈ �� ��ġ�� �����Ͽ� ���� �� O(1) ���� ����
};


struct TileRequest 
{
    int x, y, z;
};


class AFX_DATA CWMSClient1
{
public:
    CWMSClient1(HWND hWnd);
    virtual ~CWMSClient1();

public:
    void OnDrawTile(CDC* pDC);
    void MoveMap(int dx, int dy);
    void OnSize(int w, int h);

    double GetResolution() const;
    double GetCenterLon() const;
    double GetCenterLat() const;
    int GetZoom() const;
    void SetCenter(double lon, double lat);
    void SetZoom(int zoom);
    void ClampCenter();
    long CalcLevel(double Geoleft, double Geotop, double Georight, double Geobottom, CRect ClinetRect);

private:
    CCoordMgr* mCoordMgr;
    CCoord mCoord;

    HWND    m_hWnd;
    double  m_centerLon, m_centerLat;
    double  m_resolution;
    int     m_nWidth, m_nHeight;
    int     m_Level, m_startX, m_startY, m_endX, m_endY;

public:
    double getResolution();
    void CalculateVisibleRange();
    void CleanUpWorkQueue();

private:
    // 1. ĳ�� �� LRU ����
    void AddTileToCache(int x, int y, int z, CImage* pImg);
    TileData* GetTileFromCache(int x, int y, int z);
    void EvictOldest(); // ������ Ÿ�� ����
    void GetTileBBox(int x, int y, int z, double& minLon, double& minLat, double& maxLon, double& maxLat);
    CString MakeUrl(int x, int y, int z);
    void RequestTile(int x, int y, int z);
    bool IsInQueue(int x, int y, int z);
    void UpdateResolution();

    std::map<CString, TileData*> m_tileCache;
    std::list<CString> m_lruList; // �ֱ� ��� ���� ���� (������ �ֽ�)
    std::set<CString> m_queuedKeys;

    // ����ȭ (SRW Lock)
    SRWLOCK m_srwCache; // ĳ�ÿ� RW Lock
    CCriticalSection m_csQueue; // ť�� CS

    // 3. �񵿱� ������ �� ť
    std::deque<TileRequest> m_workQueue;
    HANDLE m_hThread;
    HANDLE m_hEvent;
    bool m_bIsRunning;

    static UINT DownloadThread(LPVOID pParam);

    // ��ƿ��Ƽ
    CString MakeKey(int x, int y, int z)
    {
        CString s;
        s.Format(_T("%d_%d_%d"), z, x, y);

        return s;
    };

};

#undef	AFX_DATA
#define	AFX_DATA